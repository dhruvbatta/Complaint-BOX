/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complaint.box;

 import java.util.*;
 class LinkedList1
{
    Node head;  // head of list

    /* Linked list Node.  This inner class is made static so that
       main() can access it */
   class Node {
        int data;
        String cmp;
        String title;
        String rating;
        String attachment;
        String reply;
        Date d;
        Node next;

     Node(int d,String cmp,
        String title,
        String rating,
        String attachment)  { data = d;
        this.d=new Date();
        this.cmp=cmp;
        this.title=title;
        this.rating = rating;
        this.attachment=attachment;


        next=null;
        }
     Node(String reply)  {

        this.reply=reply;


        next=null;
        }


    } // Constructor


     public  void deleteNode(int key)
    {
        // Store head node
        Node temp = head, prev = null;

        // If head node itself holds the key to be deleted
        if (temp != null && temp.data == key)
        {
            head = temp.next; // Changed head

            return;

        }

        // Search for the key to be deleted, keep track of the
        // previous node as we need to change temp.next
        while (temp != null && temp.data != key)
        {
            prev = temp;
            temp = temp.next;
            System.out.println("DONW");
        }

        // If key was not present in linked list
        if (temp == null) return;

        // Unlink the node from linked list
        prev.next = temp.next;
    }

    /* Inserts a new Node at front of the list. */
    public void push(int new_data,String cmp,
        String title,
        String rating,
        String attachment)
    {
        Node new_node = new Node(new_data,cmp,title,rating,attachment);
        new_node.next = head;
        head = new_node;
    }
     public void rep1(int new_data,String reply)
    {
        Node t=head;
        while(t!=null)
        {
            if(t.data==new_data)
            {
                t.reply=reply;
                System.out.println("done");
                break;
            }
            t=t.next;
        }
    }
  String a[]=new String[10];
    /* This function prints contents of linked list starting from head */
    public String[] printList()
    {
        Node n = head;
        int i=0;
        while (n != null)
        {
           a[i]=n.d+","+n.title+","+n.cmp+","+n.rating+","+n.attachment;
           i++;
            n = n.next;
        }
        return a;
    }
    public void printsList()
    {
        Node n = head;
        int i=0;
        while (n != null)
        {
           System.out.println(n.d+","+n.title+","+n.cmp+","+n.rating+","+n.attachment);
           i++;
            n = n.next;
        }
           }
      public String printrep(int n1)
    {
        Node n = head;

        while (n != null)
        { if(n.data==n1)
        {
            System.out.println("FOUND"+n.reply);
            String t=n.reply;
           return t;
        }

            n = n.next;
        }
        return "NO REPLY";
    }
 }

 /* Class AVLNode */
 class AVLNode
 {
     AVLNode left, right;
     int data;
     String name;
     Date date;
    /* LinkedList<String> Comp=new LinkedList<String>();
     LinkedList<String> title=new LinkedList<String>();
     LinkedList<String> rating=new LinkedList<String>();
     LinkedList<String> attachment=new LinkedList<String>();
     LinkedList<String> reply=new LinkedList<String>();
     LinkedList<String> status=new LinkedList<String>();*/
     LinkedList1 op =new LinkedList1();
     String pass;
     int height;

     /* Constructor */
     public AVLNode()
     {
         left = null;
         right = null;
         data = 0;
         height = 0;
     }
     /* Constructor */

     public AVLNode(int n,String c,String password)
     {
         left = null;
         right = null;
         data = n;
         this.pass=password;
         this.name=c;

         height = 0;
       //  System.out.println(n+"  "+password+"  "+c);
     }
 }

 /* Class AVLTree */
 class AVLTree
 {
     private AVLNode root;
 String b[]=new String[20];
     /* Constructor */
     public AVLTree()
     {
         System.out.println("CALLED");
         root = null;
         call();
     }
     /* Function to check if tree is empty */
     public boolean isEmpty()
     {
         return root == null;
     }
     /* Make the tree logically empty */
     public void makeEmpty()
     {
         root = null;
     }
     /* Function to insert data */
     public void insert(int data,String name , String p)
     {
         root = insert(data,name,p, root);
     }
     /* Function to get height of node */
     private int height(AVLNode t )
     {
         return t == null ? -1 : t.height;
     }
     /* Function to max of left/right node */
     private int max(int lhs, int rhs)
     {
         return lhs > rhs ? lhs : rhs;
     }
     /* Function to insert data recursively */
     private AVLNode insert(int x,String name , String p, AVLNode t)
     {
        // System.out.println(x+" "+name+" "+Complaint);
         if (t == null)
             t = new AVLNode(x,name,p);
         else if (x < t.data)
         {
             t.left = insert( x,name,p, t.left );
             if( height( t.left ) - height( t.right ) == 2 )
                 if( x < t.left.data )
                     t = rotateWithLeftChild( t );
                 else
                     t = doubleWithLeftChild( t );
         }
         else if( x > t.data )
         {
             t.right = insert( x,name,p, t.right );
             if( height( t.right ) - height( t.left ) == 2 )
                 if( x > t.right.data)
                     t = rotateWithRightChild( t );
                 else
                     t = doubleWithRightChild( t );
         }
         else
           ;  // Duplicate; do nothing
         t.height = max( height( t.left ), height( t.right ) ) + 1;
         return t;
     }


     /* Rotate binary tree node with left child */
     private AVLNode rotateWithLeftChild(AVLNode k2)
     {
         AVLNode k1 = k2.left;
         k2.left = k1.right;
         k1.right = k2;
         k2.height = max( height( k2.left ), height( k2.right ) ) + 1;
         k1.height = max( height( k1.left ), k2.height ) + 1;
         return k1;
     }

     /* Rotate binary tree node with right child */
     private AVLNode rotateWithRightChild(AVLNode k1)
     {
         AVLNode k2 = k1.right;
         k1.right = k2.left;
         k2.left = k1;
         k1.height = max( height( k1.left ), height( k1.right ) ) + 1;
         k2.height = max( height( k2.right ), k1.height ) + 1;
         return k2;
     }
     /**
      * Double rotate binary tree node: first left child
      * with its right child; then node k3 with new left child */
     private AVLNode doubleWithLeftChild(AVLNode k3)
     {
         k3.left = rotateWithRightChild( k3.left );
         return rotateWithLeftChild( k3 );
     }
     /**
      * Double rotate binary tree node: first right child
      * with its left child; then node k1 with new right child */
     private AVLNode doubleWithRightChild(AVLNode k1)
     {
         k1.right = rotateWithLeftChild( k1.right );
         return rotateWithRightChild( k1 );
     }
     /* Functions to count number of nodes */
     public int countNodes()
     {
         return countNodes(root);
     }
     private int countNodes(AVLNode r)
     {
         if (r == null)
             return 0;
         else
         {
             int l = 1;
             l += countNodes(r.left);
             l += countNodes(r.right);
             return l;
         }
     }
     /* Functions to search for an element */
     public boolean search(int val)
     {
         return search(root, val);
     }
     private boolean search(AVLNode r, int val)
     {
         boolean found = false;
         while ((r != null) && !found)
         {
             int rval = r.data;
             if (val < rval)
                 r = r.left;
             else if (val > rval)
                 r = r.right;
             else
             {
                 found = true;
                 System.out.println(r.name+"  ");
                 break;
             }
             found = search(r, val);
         }
         return found;
     }

     String c[]=new String[10];
     int i=0;
     public String[] in1()
     {
         in(root);
         return c;
     }
     public void in(AVLNode r)
     {
       if(r==null)
           return;
       in(r.left);
       in(r.right);


       if(r.op.printList()[0]!=null)
       {
           c[i]=r.name;
           i++;
           System.out.println(i);
       }




     }

     public int decode(String a) {
        a = a.toUpperCase();
        char a1[] = a.toCharArray();
        int s = 0;
        for (int i = 0; i < a.length(); i++) {
            s = s + i * (int) a1[i];
        }
        return s;
    }
     public String verif(String userid,String pass)
     {

       AVLNode r;
       r=root;
       String s;
       System.out.println(userid+"  "+pass);
      int t=decode(userid);
       while(r!=null)
       {
           if(r.data==decode(userid))
           {
               //System.out.println(pass);
               if(r.pass.equals(pass))
               {
                  s="PROCESSED";


                  return s;
               }
               else
               {
                   s="FALSE PASSWORD ";
                   return s;
               }
           }
            else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;


       }
       return "false";
     }
 /*String a[]=new String[10];
    public void addCO(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {

               r.Comp.add(c);
               r.date=new Date();
 Iterator<String> itr=r.Comp.iterator();

  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;

       }



     }
     public void addCOup(String userid,String c,String d)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {


               r.date=new Date();
 Iterator<String> itr=r.Comp.iterator();
 int i=0;
 while(itr.hasNext())
 {
     if(itr.next().equals(d))
     {
         r.Comp.add(i, c);
         System.out.println(r.Comp);
     }
     else
     {
         i=i+1;
     }

 }


  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;

       }



     }
    public void addCO2(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {

               r.title.add(c);


  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;

       }



     }
    public void addCO3(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {

               r.rating.add(c);



  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;

       }



     }
      public void rep(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {

               r.reply.add(c);
               System.out.println(r.reply);


  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;

       }



     }
    public void addCO4(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {

               r.attachment.add(c);


  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;

       }



     }*/
       public void addCO45(String userid,String cmp,
        String title,
        String rating,
        String attachment)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {

               r.op.push(t,cmp,title,rating,attachment);
               r.op.printList();

  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;

       }



     }
     public String[] addCO1(String userid)
     {
      // System.out.println("hiii");
       AVLNode r;
       r=root;

      int t=decode(userid);
      int i=0;
        while(r!=null)
       {
           if(r.data==t)
           {

            String x[]=r.op.printList();

  return x;


           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;

       }

return null;


     }

     public void rmv(String userid,String c,String tq,String at,String ret)
     {
      // System.out.println("hiii");
       AVLNode r;
       r=root;

      int t=decode(userid);
      while(r!=null)
      {
          if(r.data==t)
          {
             r.op.deleteNode(t);

             String r4[]=r.op.printList();
             for(int i=0;i<r4.length;i++)
                 System.out.println(r4[i]);
             return;
          }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
      }


     }

     public void rep(String reply,String t)
     {
         int y=decode(t);
           AVLNode r;
       r=root;
       while(r!=null)
       {
           if(r.data == decode(t))
           {
               r.op.rep1(decode(t), reply);
               break;
           }
					 else if(r.data > decode(t))
               r=r.left;
					 else if(r.data < decode(t))
               r=r.right;
       }
     }

     public String rp(String t)
     {
         AVLNode t1;
         t1=root;
         int y=decode(t);
         while(t!=null)
         {

             if(t1.data==y)
             {
                 String r=t1.op.printrep(y);
                 return r;
             }
             if(t1.data>y)
                 t1=t1.left;
               if(t1.data<y)
                 t1=t1.right;
         }

         return "NOT FOUND";
     }



    public void call()
    {
        insert(decode("17BEC7039"),"17BEC7039","ashita");
        insert(decode("17BCE7100"),"17BCE7100","tathagat");
        insert(decode("17BCE7105"),"17BCE7105","unknown");
        insert(decode("17BES7002"),"17BES7002","ankur");
      /*addCO("17BCE7100","tsom");
      addCO2("17BCE7100","4");
      addCO3("17BCE7100","tojio");
      addCO4("17BCE7100","tsom");
      rep("17BCE7100","OKAY");*/
        addCO45("17BCE7100","it is content","Faculty ", "4","attach");
        rep("hii","17BCE7100");
        addCO45("17BCE7100","it is1 content","ID-card ", "5","image");
                rep("hii1111","17BCE7100");
    /*  addCO("17BCE7100","tsom1");
      addCO2("17BCE7100","5");
      addCO3("17BCE7100","tojio1");
      addCO4("17BCE7100","tsom1");
       rep("17BCE7100","OKAY");
      addCO("17BCE7105","tsom");
      addCO2("17BCE7105","4");
      addCO3("17BCE7105","tojio");
      addCO4("17BCE7105","tsom");
       rep("17BCE7100","OKAY");*/
        addCO45("17BCE7105","it is567 content","Hostel", "5","a.txt");
     /* addCO("17BCE7105","tsom1");
      addCO2("17BCE7105","5");
      addCO3("17BCE7105","tojio1");
      addCO4("17BCE7105","tsom1");
       rep("17BCE7100","OKAY");*/

    }
 }
public class Design extends javax.swing.JFrame {

    /**
     * Creates new form Design
     */



     AVLTree avlt=new AVLTree();


    public Design() {

      /* Admin s =new Admin(avlt);
       s.setVisible(true);
       this.setVisible(false);
       dispose();*/
			setVisible(true);
			setSize(500,500);
      initComponents();

    }

		public Design(AVLTree avlt) {
         this.avlt=avlt;
      /* Admin s =new Admin(avlt);
       s.setVisible(true);
       this.setVisible(false);
       dispose();*/
      initComponents();

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
  // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
  private void initComponents() {

    jLabel3 = new javax.swing.JLabel();
    mb2 = new javax.swing.JButton();
    mb1 = new javax.swing.JButton();
    mb3 = new javax.swing.JButton();
    jLabel1 = new javax.swing.JLabel();

    setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    
    getContentPane().setLayout(null);

    jLabel3.setFont(new java.awt.Font("Arial Narrow", 3, 24)); // NOI18N
    jLabel3.setText("COMPLAINT BOX");
    getContentPane().add(jLabel3);
    jLabel3.setBounds(130, 50, 270, 32);

    mb2.setText("New Complain");
    mb2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        mb2ActionPerformed(evt);
      }
    });
    getContentPane().add(mb2);
    mb2.setBounds(60, 140, 180, 70);

    mb1.setText("User Login");
    mb1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        mb1ActionPerformed(evt);
      }
    });
    getContentPane().add(mb1);
    mb1.setBounds(280, 140, 150, 70);

    mb3.setText("ADMIN ");
    mb3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        mb3ActionPerformed(evt);
      }
    });
    getContentPane().add(mb3);
    mb3.setBounds(170, 310, 190, 60);

    jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Shabbi\\Desktop\\iconImage2.png")); // NOI18N
    jLabel1.setText("jLabel1");
    getContentPane().add(jLabel1);
    jLabel1.setBounds(0, 0, 510, 410);

    pack();
  }// </editor-fold>//GEN-END:initComponents

  private void mb2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mb2ActionPerformed
    // TODO add your handling code here:
    NewRegistration newr = new NewRegistration(avlt);
    newr.setVisible(true);
    this.setVisible(false);
    this.dispose();
  }//GEN-LAST:event_mb2ActionPerformed

  private void mb1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mb1ActionPerformed
Sign n=new Sign(avlt);
n.setVisible(true);
this.setVisible(false);
dispose();

// TODO add your handling code here:

  }//GEN-LAST:event_mb1ActionPerformed

  private void mb3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mb3ActionPerformed
   admin_login s =new admin_login(avlt);
       s.setVisible(true);
       this.setVisible(false);
       dispose();
		// TODO add your handling code here:
  }//GEN-LAST:event_mb3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Design().setVisible(true);
            }
        });
    }

  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JLabel jLabel1;
  private javax.swing.JLabel jLabel3;
  private javax.swing.JButton mb1;
  private javax.swing.JButton mb2;
  private javax.swing.JButton mb3;
  // End of variables declaration//GEN-END:variables
}
