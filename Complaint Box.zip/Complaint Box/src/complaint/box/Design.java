/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complaint.box;

 import java.util.*;
 
 /* Class AVLNode */
 class AVLNode
 {    
     AVLNode left, right;
     int data;
     String name;
     Date date;
     LinkedList<String> Comp=new LinkedList<String>();  
     LinkedList<String> title=new LinkedList<String>(); 
     LinkedList<String> rating=new LinkedList<String>(); 
     LinkedList<String> attachment=new LinkedList<String>(); 
     LinkedList<String> reply=new LinkedList<String>(); 
     String pass;
     int height;
 
     /* Constructor */
     public AVLNode()
     {
         left = null;
         right = null;
         data = 0;
         height = 0;
     }
     /* Constructor */
     
     public AVLNode(int n,String c,String password)
     {
         left = null;
         right = null;
         data = n;
         this.pass=password;
         this.name=c;
         
         height = 0;
       //  System.out.println(n+"  "+password+"  "+c);
     } 
 }
 
 /* Class AVLTree */
 class AVLTree
 {
     private AVLNode root;     
 String b[]=new String[20];
     /* Constructor */
     public AVLTree()
     {
         System.out.println("CALLED");
         root = null;
         call();
     }
     /* Function to check if tree is empty */
     public boolean isEmpty()
     {
         return root == null;
     }
     /* Make the tree logically empty */
     public void makeEmpty()
     {
         root = null;
     }
     /* Function to insert data */
     public void insert(int data,String name , String p)
     {
         root = insert(data,name,p, root);
     }
     /* Function to get height of node */
     private int height(AVLNode t )
     {
         return t == null ? -1 : t.height;
     }
     /* Function to max of left/right node */
     private int max(int lhs, int rhs)
     {
         return lhs > rhs ? lhs : rhs;
     }
     /* Function to insert data recursively */
     private AVLNode insert(int x,String name , String p, AVLNode t)
     {
        // System.out.println(x+" "+name+" "+Complaint);
         if (t == null)
             t = new AVLNode(x,name,p);
         else if (x < t.data)
         {
             t.left = insert( x,name,p, t.left );
             if( height( t.left ) - height( t.right ) == 2 )
                 if( x < t.left.data )
                     t = rotateWithLeftChild( t );
                 else
                     t = doubleWithLeftChild( t );
         }
         else if( x > t.data )
         {
             t.right = insert( x,name,p, t.right );
             if( height( t.right ) - height( t.left ) == 2 )
                 if( x > t.right.data)
                     t = rotateWithRightChild( t );
                 else
                     t = doubleWithRightChild( t );
         }
         else
           ;  // Duplicate; do nothing
         t.height = max( height( t.left ), height( t.right ) ) + 1;
         return t;
     }
     
        
     /* Rotate binary tree node with left child */     
     private AVLNode rotateWithLeftChild(AVLNode k2)
     {
         AVLNode k1 = k2.left;
         k2.left = k1.right;
         k1.right = k2;
         k2.height = max( height( k2.left ), height( k2.right ) ) + 1;
         k1.height = max( height( k1.left ), k2.height ) + 1;
         return k1;
     }
 
     /* Rotate binary tree node with right child */
     private AVLNode rotateWithRightChild(AVLNode k1)
     {
         AVLNode k2 = k1.right;
         k1.right = k2.left;
         k2.left = k1;
         k1.height = max( height( k1.left ), height( k1.right ) ) + 1;
         k2.height = max( height( k2.right ), k1.height ) + 1;
         return k2;
     }
     /**
      * Double rotate binary tree node: first left child
      * with its right child; then node k3 with new left child */
     private AVLNode doubleWithLeftChild(AVLNode k3)
     {
         k3.left = rotateWithRightChild( k3.left );
         return rotateWithLeftChild( k3 );
     }
     /**
      * Double rotate binary tree node: first right child
      * with its left child; then node k1 with new right child */      
     private AVLNode doubleWithRightChild(AVLNode k1)
     {
         k1.right = rotateWithLeftChild( k1.right );
         return rotateWithRightChild( k1 );
     }    
     /* Functions to count number of nodes */
     public int countNodes()
     {
         return countNodes(root);
     }
     private int countNodes(AVLNode r)
     {
         if (r == null)
             return 0;
         else
         {
             int l = 1;
             l += countNodes(r.left);
             l += countNodes(r.right);
             return l;
         }
     }
     /* Functions to search for an element */
     public boolean search(int val)
     {
         return search(root, val);
     }
     private boolean search(AVLNode r, int val)
     {
         boolean found = false;
         while ((r != null) && !found)
         {
             int rval = r.data;
             if (val < rval)
                 r = r.left;
             else if (val > rval)
                 r = r.right;
             else
             {
                 found = true;
                 System.out.println(r.name+"  ");
                 break;
             }
             found = search(r, val);
         }
         return found;
     }
     /* Function for inorder traversal */
     public String[] inorder()
     {
         inorder(root,0);
         return b;
     }
     private void inorder(AVLNode r,int i)
     {
         if (r != null)
         {
             i=i+1;
             inorder(r.left,i);
             {
                 b[i]=r.name+" ,"+r.Comp+r.rating+" ,"+r.title+" ,"+r.attachment+" ,"+r.date;
                // System.out.println(r.name+" ,"+r.Comp+r.rating+" ,"+r.title+" ,"+r.attachment+" ,"+r.date);
                 i=i+1;
             }
             inorder(r.right,i);
         }
     }
 
     public int decode(String a) {
        a = a.toUpperCase();
        char a1[] = a.toCharArray();
        int s = 0;
        for (int i = 0; i < a.length(); i++) {
            s = s + i * (int) a1[i];
        }
        return s;
    }
     public String verif(String userid,String pass)
     {
        
       AVLNode r;
       r=root;
       String s;
       System.out.println(userid+"  "+pass);
      int t=decode(userid);
       while(r!=null)
       {
           if(r.data==decode(userid))
           {
               //System.out.println(pass);
               if(r.pass.equals(pass))
               {
                  s="PROCESSED";
              
                
                  return s;
               }
               else
               {
                   s="FALSE PASSWORD ";
                   return s;
               }
           }
            else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
          
           
       }
       return "false";
     }
 String a[]=new String[10];
    public void addCO(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {
              
               r.Comp.add(c);
               r.date=new Date();
 Iterator<String> itr=r.Comp.iterator();  

  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
           
       }

  
   
     }
     public void addCOup(String userid,String c,String d)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {
              
               
               r.date=new Date();
 Iterator<String> itr=r.Comp.iterator();
 int i=0;
 while(itr.hasNext())
 {
     if(itr.next().equals(d))
     {
         r.Comp.add(i, c);
         System.out.println(r.Comp);
     }
     else
     {
         i=i+1;
     }
     
 }
 

  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
           
       }

  
   
     }
    public void addCO2(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {
              
               r.title.add(c);
             

  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
           
       }

  
   
     }
    public void addCO3(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {
              
               r.rating.add(c);
               
  

  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
           
       }

  
   
     }
      public void rep(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {
              
               r.reply.add(c);
               System.out.println(r.reply);
  

  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
           
       }

  
   
     }
    public void addCO4(String userid,String c)
     {
       AVLNode r;
       r=root;
       String s;
      int t=decode(userid);
        while(r!=null)
       {
           if(r.data==t)
           {
              
               r.attachment.add(c);
                

  break;
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
           
       }

  
   
     }
     public String[] addCO1(String userid)
     {
      // System.out.println("hiii");
       AVLNode r;
       r=root;
       
      int t=decode(userid);
      int i=0;
        while(r!=null)
       {
           if(r.data==t)
           {
              // System.out.println("match");
     Iterator<String> itr=r.Comp.iterator();  
     Iterator<String> itr1=r.title.iterator();  
     Iterator<String> itr2=r.rating.iterator();  
     Iterator<String> itr3=r.attachment.iterator();  
      Iterator<String> itr4=r.reply.iterator(); 

      while(itr.hasNext()&&itr1.hasNext()&&itr2.hasNext()&&itr3.hasNext()&&itr4.hasNext()){  

       String x=  itr.next()+","+r.date+","+itr1.next()+","+itr2.next()+","+itr3.next()+","+itr4.next();
     a[i]=x;
       // System.out.println("this   "+a[i]);
       i++;

      }
  return a;

             
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
           
       }
       
return a;
  
   
     }
     public String[] rmv(String userid,String c,String tq,String at,String ret)
     {
      // System.out.println("hiii");
       AVLNode r;
       r=root;
       
      int t=decode(userid);
      int i=0;
        while(r!=null)
       {
           if(r.data==t)
           {
              // System.out.println("match");
     Iterator<String> itr=r.Comp.iterator();  
     Iterator<String> itr1=r.title.iterator();  
     Iterator<String> itr2=r.rating.iterator();  
     Iterator<String> itr3=r.attachment.iterator();  
      Iterator<String> itr4=r.reply.iterator(); 

      while(itr.hasNext()&&itr1.hasNext()&&itr2.hasNext()&&itr3.hasNext()&&itr4.hasNext()){  

          if(itr.next().equals(c))
          {
              System.out.println("rehed");
              r.Comp.remove("tom");
              r.title.remove(tq);
              r.rating.remove(ret);
              r.attachment.remove(at);
              System.out.println(r.Comp);
              
          }

      }
  return a;

             
           }
           else if(t<r.data)
               r=r.left;
           else if(t>r.data)
               r=r.right;
           
       }
       
return a;
  
   
     }
     
    public void call()
    {
        insert(decode("17BEC7039"),"17BEC7039","ashita");
        insert(decode("17BCE7100"),"17BCE7100","tathagat");
        insert(decode("17BCE7105"),"17BCE7105","unknown");
        insert(decode("17BES7002"),"17BES7002","ankur");
      addCO("17BCE7100","tsom");
      addCO2("17BCE7100","4");
      addCO3("17BCE7100","tojio");
      addCO4("17BCE7100","tsom");
      rep("17BCE7100","OKAY");
        addCO("17BCE7100","tom1");
      addCO("17BCE7100","tsom1");
      addCO2("17BCE7100","5");
      addCO3("17BCE7100","tojio1");
      addCO4("17BCE7100","tsom1");
       rep("17BCE7100","OKAY");
      addCO("17BCE7105","tsom");
      addCO2("17BCE7105","4");
      addCO3("17BCE7105","tojio");
      addCO4("17BCE7105","tsom");
       rep("17BCE7100","OKAY");
        addCO("17BCE7105","tom1");
      addCO("17BCE7105","tsom1");
      addCO2("17BCE7105","5");
      addCO3("17BCE7105","tojio1");
      addCO4("17BCE7105","tsom1");
       rep("17BCE7100","OKAY");
        
    }
 }
public class Design extends javax.swing.JFrame {

    /**
     * Creates new form Design
     */
   
     
     
     AVLTree avlt=new AVLTree();
     

    public Design() {
         /* 
       Admin s =new Admin(avlt);
       s.setVisible(true);
       this.setVisible(false);*/
      initComponents();
      
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        t = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        t3 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        t4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        t2 = new javax.swing.JPasswordField();
        t1 = new javax.swing.JPasswordField();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel1.setText("USER");

        jLabel2.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel2.setText("Password");

        jButton2.setText("Sign In");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial Narrow", 3, 24)); // NOI18N
        jLabel3.setText("COMPLAINT");

        jLabel4.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel4.setText("NAME");

        jLabel5.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel5.setText("Password");

        jLabel6.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel6.setText("Registration No.");

        jButton1.setText("Log In");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tempus Sans ITC", 3, 18)); // NOI18N
        jLabel7.setText("NEW ? Please Log IN");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(51, 51, 51)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(t4)
                                    .addComponent(t3)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(t2, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(t, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(79, 79, 79)
                                .addComponent(t1))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(101, 101, 101)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(144, 144, 144)
                                .addComponent(jButton2)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(129, 129, 129)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(t, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addGap(9, 9, 9)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(t3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(t2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(t4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

    String r=t.getText();
    String r1=t1.getText();
    String r2=avlt.verif(r, r1);
    if(r2.equalsIgnoreCase("PROCESSED"))
    {  student s =new student(avlt,r);
    s.setVisible(true);
    this.setVisible(false);
    dispose();  
    }
else
    {
System.out.println(r2 +" "+r1);
    }// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
   String r =t3.getText();
   String r2=t2.getText();
   String r1=t4.getText();
        avlt.insert(avlt.decode(r1), r, r2);

// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(student.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Design().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField t;
    private javax.swing.JPasswordField t1;
    private javax.swing.JPasswordField t2;
    private javax.swing.JTextField t3;
    private javax.swing.JTextField t4;
    // End of variables declaration//GEN-END:variables
}
